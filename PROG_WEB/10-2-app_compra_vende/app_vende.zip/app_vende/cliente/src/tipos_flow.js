export type Autor = {|
    nome: string,
    matricula: number
  |}
